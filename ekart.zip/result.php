<?php include "includes/db.php"; 

include "functions.php";


?>
