<?php 

$con = mysqli_connect("localhost","root","","ekartt");
if($con){
    // echo "connected";
}
else{
    echo "not-connected";
}



?>