<!-- Footer ================================================================== -->
<div id="footerSection">
                <div class="container">
                    <div class="row">
                        <div class="span3">
                            <h5>ACCOUNT</h5>
                            <a href="account.php">YOUR ACCOUNT</a>
                            <a href="register.php">PERSONAL INFORMATION</a>
                            <a href="account.php?my_orders">ORDER HISTORY</a>
                        </div>
                        <div class="span3">
                            <h5>INFORMATION</h5>
                            <!-- <a href="contact.php">CONTACT</a> -->
                            <a href="register.php">REGISTRATION</a>
                            <!-- <a href="legal_notice.php">LEGAL NOTICE</a> -->
                            <!-- <a href="tac.php">TERMS AND CONDITIONS</a> -->
                            <!-- <a href="faq.php">FAQ</a> -->
                        </div>
                        
                        <div id="socialMedia" class="span3 pull-right">
                            <h5>SOCIAL MEDIA </h5>
                            <a href="#"><img width="60" height="60" src="themes/images/facebook.png" title="facebook" alt="facebook" /></a>
                            <a href="#"><img width="60" height="60" src="themes/images/twitter.png" title="twitter" alt="twitter" /></a>
                            <a href="#"><img width="60" height="60" src="themes/images/youtube.png" title="youtube" alt="youtube" /></a>
                        </div>
                    </div>
                </div>